<?php

use yii\db\Migration;

class m130524_201442_init extends Migration
{
    public function up()
    {
        $tableOptions = null;
        if ($this->db->driverName === 'mysql') {
            // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
            $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
        }

        $this->createTable('{{%user}}', [
            'id' => $this->primaryKey()->unsigned(),
            'name' => $this->string()->notNull(),
            'password_hash' => $this->string()->notNull(),

            //add something else

            'created_at' => $this->timestamp()->notNull()->defaultValue('1999-01-01 00:00:00'),//prevent "current timestamp" behavior on update
            'updated_at' => $this->timestamp()->notNull()->defaultValue('1999-01-01 00:00:00'),
        ], $tableOptions);

        $this->createTable('{{%session}}', [
            'token' => $this->string(64)->notNull(),
            'user_id' => $this->integer()->notNull()->unsigned(),
            'created_at' => $this->timestamp()->notNull()->defaultValue('1999-01-01 00:00:00'),
        ], $tableOptions);

        $this->addPrimaryKey('session-pk', '{{%session}}', 'token');
        $this->createIndex('session-user-index', '{{%session}}', 'user_id');
        $this->addForeignKey('session-user-fk', '{{%session}}', 'user_id',
            '{{%user}}', 'id', 'CASCADE', 'CASCADE');

        $this->createTable('{{%admin}}', [
            'id' => $this->primaryKey(),
            'email' => $this->string(128)->unique()->notNull(),
            'auth_key' => $this->string(32)->notNull(),
            'password_hash' => $this->string()->notNull(),
            'password_reset_token' => $this->string(64)->unique(),
            'created_at' => $this->timestamp()->notNull()->defaultValue('1999-01-01 00:00:00'),
            'updated_at' => $this->timestamp()->notNull()->defaultValue('1999-01-01 00:00:00'),
        ], $tableOptions);
    }

    public function down()
    {
        $this->dropTable('{{%session}}');
        $this->dropTable('{{%user}}');
        $this->dropTable('{{%admin}}');
    }
}
